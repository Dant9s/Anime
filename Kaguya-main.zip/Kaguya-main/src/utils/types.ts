export type ArrayElement<ArrayType extends any[]> = ArrayType[number];
